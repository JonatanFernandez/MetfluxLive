"""Consolidated model quality-control checks for Human-GEM.

A single entry point for the structural checks. Each check writes a detailed,
diff-friendly CSV under data/testResults/ so that whatever is wrong is spelled
out in a committed file (not only in the workflow log), and buildReport.py turns
the same files into the pull-request comment.

Checks split into two kinds:

  * Gates (fail the build): a model that has these problems is broken.
      - duplicate keys inside an !!omap entry (cobra cannot load the model);
      - reactions with no metabolites;
      - the model and its annotation tables (reactions.tsv / metabolites.tsv /
        genes.tsv) disagree, or a deprecated identifier is used;
      - the model cannot produce biomass on a defined medium (Ham's medium from the
        GR metabolic task, each nutrient's uptake capped; the blocking biomass
        precursors are written out so it can be fixed).
  * Reports (do not fail): quality metrics tracked with a delta versus the
      target branch.
      - metabolites missing a formula or a charge;
      - reaction bound / GPR sanity;
      - exact-duplicate reactions (same stoichiometry);
      - reactions whose chemistry is split across compartments;
      - metabolites and genes not used by any reaction;
      - identifiers removed since the base branch that were not moved to a
        deprecated list (needs BASE_MODEL_DIR; skipped when unavailable).

Usage:
    python code/test/qcModelChecks.py
"""

import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

import cobra
import yaml

import qcStatus

MODEL_FILE = "model/Human-GEM.yml"
GENES_TSV = "model/genes.tsv"
REACTIONS_TSV = "model/reactions.tsv"
METABOLITES_TSV = "model/metabolites.tsv"
DEPRECATED_RXN_TSV = "data/deprecatedIdentifiers/deprecatedReactions.tsv"
DEPRECATED_MET_TSV = "data/deprecatedIdentifiers/deprecatedMetabolites.tsv"

RESULTS = "data/testResults"
DUP_KEYS_CSV = f"{RESULTS}/qc_duplicate_keys.csv"
DUP_RXN_CSV = f"{RESULTS}/qc_duplicate_reactions.csv"
SPLIT_COMPARTMENT_CSV = f"{RESULTS}/qc_split_compartments.csv"
EMPTY_RXN_CSV = f"{RESULTS}/qc_empty_reactions.csv"
ANNOTATION_CONSISTENCY_CSV = f"{RESULTS}/qc_annotation_consistency.csv"
UNUSED_CSV = f"{RESULTS}/qc_unused_entities.csv"
COMPLETENESS_CSV = f"{RESULTS}/qc_metabolite_completeness.csv"
REACTION_SANITY_CSV = f"{RESULTS}/qc_reaction_sanity.csv"
DEPRECATION_COMPLETENESS_CSV = f"{RESULTS}/qc_deprecation_completeness.csv"
NAME_CONSISTENCY_CSV = f"{RESULTS}/qc_name_consistency.csv"
# Growth value goes into the shared qc_status.tsv (via qcStatus); only the
# variable-length list of blocking precursors keeps its own CSV.
GROWTH_BLOCKERS_CSV = f"{RESULTS}/qc_growth_blockers.csv"

# Base-branch copies of reactions.tsv / metabolites.tsv, used to spot identifiers
# this pull request removed from the model. The workflow fetches them from the
# target branch; empty (check skipped) when run locally or on the first comparison.
BASE_MODEL_DIR = os.environ.get("BASE_MODEL_DIR", "")

GROWTH_TOLERANCE = 1e-6

# Growth is tested on a defined medium rather than the model's default bounds, which
# leave most uptakes open at 1000: there the value mostly reflects which uptake and
# secretion routes exist, and one new route can shift it a lot. The medium is Ham's
# medium as defined by the GR (growth) essential metabolic task; every other uptake is
# closed and secretion stays open. Each nutrient's uptake is capped at
# MEDIUM_UPTAKE_CAP, so growth is limited by the nutrients, not by a flux bound;
# the value is comparable between commits, not a physiological growth rate.
MEDIUM_TASKS_FILE = "data/metabolicTasks/metabolicTasks_Essential.txt"
MEDIUM_TASK_ID = "GR"
MEDIUM_UPTAKE_CAP = 1.0
MEDIUM_UNCAPPED = {"O2", "H2O"}

# Pseudo-metabolites (generic class sinks and biomass pools) intrinsically
# have no molecular formula, so they are excluded from the completeness report.
PSEUDO_METABOLITES = {
    "MAM10001", "MAM10002", "MAM10003",              # steroids, xenobiotics, arachidonate derivatives
    "MAM10012", "MAM10013", "MAM10014", "MAM10015",  # cofactor/protein/lipid/metabolite pool_biomass
}


def _tsv_column(path: str, column: str) -> list[str]:
    with open(path, newline="", encoding="utf-8") as fh:
        return [row[column] for row in csv.DictReader(fh, delimiter="\t")]


def _write_csv(path: str, header: list[str], rows: list) -> None:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(header)
        writer.writerows(rows)


# --------------------------------------------------------------------------- #
# Gate: duplicate keys inside an !!omap entry (cobra cannot load such a model)
# --------------------------------------------------------------------------- #
def check_no_duplicate_keys(model_file: str) -> list[tuple]:
    """Return [(entry_id, scope, key, first_line, dup_line)] for duplicate !!omap keys.

    Every metabolite, reaction and gene is an !!omap; a repeated key inside one
    (two 'name' fields, or the same metabolite twice in a stoichiometry) is
    written and re-read happily by RAVEN but makes cobra.io.load_yaml_model raise
    a bare AssertionError with no location. This scan names the entry, key and
    line numbers.
    """
    stack: list[dict] = []
    expect: list[str] = []
    firsts: list[list] = []
    dups: list[tuple] = []

    def owner() -> str:
        for ctx in reversed(stack):
            if ctx["type"] == "omap" and ctx["id"]:
                return ctx["id"]
        return "(top level)"

    with open(model_file, encoding="utf-8") as fh:
        for event in yaml.parse(fh):
            kind = type(event).__name__
            line = event.start_mark.line + 1
            if kind == "SequenceStartEvent":
                is_omap = event.tag == "tag:yaml.org,2002:omap"
                stack.append({"type": "omap" if is_omap else "seq", "keys": {}, "id": None})
            elif kind == "SequenceEndEvent":
                stack.pop()
            elif kind == "MappingStartEvent":
                stack.append({"type": "map"})
                expect.append("key")
                firsts.append([None, None])
            elif kind == "MappingEndEvent":
                stack.pop()
                first_key, first_val = firsts.pop()
                expect.pop()
                if stack and stack[-1]["type"] == "omap" and first_key is not None:
                    parent = stack[-1]
                    if first_key in parent["keys"]:
                        scope = "field" if parent["id"] else "member"
                        dups.append((owner(), scope, first_key, parent["keys"][first_key], line))
                    else:
                        parent["keys"][first_key] = line
                    if first_key == "id" and parent["id"] is None:
                        parent["id"] = first_val
            elif kind == "ScalarEvent" and stack and stack[-1]["type"] == "map":
                i = len(expect) - 1
                if expect[i] == "key":
                    if firsts[i][0] is None:
                        firsts[i][0] = event.value
                    expect[i] = "val"
                else:
                    if firsts[i][1] is None:
                        firsts[i][1] = event.value
                    expect[i] = "key"

    _write_csv(DUP_KEYS_CSV, ["entry", "scope", "key", "first_line", "duplicate_line"],
               sorted(dups))
    return dups


# --------------------------------------------------------------------------- #
# Gate: reactions with no metabolites
# --------------------------------------------------------------------------- #
def check_empty_reactions(model: cobra.Model) -> list[str]:
    empty = sorted(r.id for r in model.reactions if len(r.metabolites) == 0)
    _write_csv(EMPTY_RXN_CSV, ["reaction"], [(rid,) for rid in empty])
    return empty


# --------------------------------------------------------------------------- #
# Gate: the model and its annotation tables must agree; no deprecated ids
# --------------------------------------------------------------------------- #
def check_annotation_consistency(model: cobra.Model) -> list[tuple]:
    """Compare model ids against reactions/metabolites/genes.tsv and the deprecated
    lists, and each metabolite id's compartment suffix against its compartment.
    Returns [(kind, id, issue)]."""
    issues: list[tuple] = []

    def compare(kind: str, in_model: set[str], in_tsv: set[str], deprecated: set[str]):
        for used in sorted(in_model & deprecated):
            issues.append((kind, used, "deprecated identifier used"))
        for missing in sorted(in_model - in_tsv):
            issues.append((kind, missing, f"in model but not in the {kind} table"))
        for orphan in sorted(in_tsv - in_model):
            issues.append((kind, orphan, f"in the {kind} table but not in the model"))

    compare("reaction",
            {r.id for r in model.reactions}, set(_tsv_column(REACTIONS_TSV, "rxns")),
            set(_tsv_column(DEPRECATED_RXN_TSV, "rxns")))
    compare("metabolite",
            {m.id for m in model.metabolites}, set(_tsv_column(METABOLITES_TSV, "mets")),
            set(_tsv_column(DEPRECATED_MET_TSV, "mets")))
    # genes.tsv has no deprecated list; only check presence in both directions.
    compare("gene",
            {g.id for g in model.genes}, set(_tsv_column(GENES_TSV, "genes")), set())

    # A metabolite id ends in its compartment; a mismatch puts the metabolite somewhere
    # other than its id says, which no id-based review can see.
    for met in model.metabolites:
        if met.id[-1] != met.compartment:
            issues.append(("metabolite", met.id,
                           f"id suffix '{met.id[-1]}' but compartment '{met.compartment}'"))

    # The 'spontaneous' column in reactions.tsv must be numeric (RAVEN reads it).
    def _numeric(value: str) -> bool:
        try:
            float(value)
            return True
        except ValueError:
            return False

    non_numeric = [v for v in _tsv_column(REACTIONS_TSV, "spontaneous") if v.strip() and not _numeric(v)]
    if non_numeric:
        issues.append(("reactions.tsv", "spontaneous",
                       f"{len(non_numeric)} non-numeric value(s) in the spontaneous column"))

    _write_csv(ANNOTATION_CONSISTENCY_CSV, ["kind", "id", "issue"], issues)
    return issues


# --------------------------------------------------------------------------- #
# Report: removed identifiers must be moved to the deprecated lists
# --------------------------------------------------------------------------- #
def check_deprecation_completeness(model: cobra.Model) -> list[tuple]:
    """Reactions/metabolites present in the base branch but gone from this model
    must appear in the matching deprecated identifier file. Returns [(kind, id, issue)].

    Human-GEM's convention is to retire identifiers, never silently delete them, so a
    removed identifier stays resolvable. Detection needs the base-branch model tables
    (BASE_MODEL_DIR); the check is skipped (empty result) when they are not available,
    e.g. locally or on the first comparison for a branch.
    """
    rows: list[tuple] = []
    if not BASE_MODEL_DIR or not Path(BASE_MODEL_DIR).exists():
        _write_csv(DEPRECATION_COMPLETENESS_CSV, ["kind", "id", "issue"], rows)
        return rows

    current = {
        "reaction": {r.id for r in model.reactions},
        "metabolite": {m.id for m in model.metabolites},
    }
    # (kind, base table, id column, deprecated list, deprecated id column)
    specs = [
        ("reaction", "reactions.tsv", "rxns", DEPRECATED_RXN_TSV, "rxns"),
        ("metabolite", "metabolites.tsv", "mets", DEPRECATED_MET_TSV, "mets"),
    ]
    for kind, base_name, base_col, dep_tsv, dep_col in specs:
        base_path = Path(BASE_MODEL_DIR) / base_name
        if not base_path.exists():
            continue
        base_ids = set(_tsv_column(str(base_path), base_col))
        deprecated = set(_tsv_column(dep_tsv, dep_col))
        removed = base_ids - current[kind]
        for missing in sorted(removed - deprecated):
            issue = f"removed from the model but not listed in {Path(dep_tsv).name}"
            rows.append((kind, missing, issue))

    _write_csv(DEPRECATION_COMPLETENESS_CSV, ["kind", "id", "issue"], rows)
    return rows


# --------------------------------------------------------------------------- #
# Report: exact-duplicate reactions (identical stoichiometry)
# --------------------------------------------------------------------------- #
def check_duplicate_reactions(model: cobra.Model) -> int:
    """Group reactions that share an identical metabolite -> coefficient mapping.

    This is the strict "truly identical" duplicate. Near-duplicates (reverse
    direction, different coefficients, different electron carriers) are the
    remit of the MACAW duplicate_test report, which keeps its own detail.
    """
    by_signature: dict[frozenset, list[str]] = defaultdict(list)
    for rxn in model.reactions:
        signature = frozenset((met.id, coeff) for met, coeff in rxn.metabolites.items())
        if signature:
            by_signature[signature].append(rxn.id)

    rows: list[tuple] = []
    group = 0
    for members in by_signature.values():
        if len(members) > 1:
            group += 1
            example = model.reactions.get_by_id(members[0]).build_reaction_string()
            for rid in sorted(members):
                rows.append((group, rid, example))
    rows.sort()
    _write_csv(DUP_RXN_CSV, ["group", "reaction", "equation"], rows)
    return group


# --------------------------------------------------------------------------- #
# Report: reactions whose chemistry is split across compartments
# --------------------------------------------------------------------------- #
def check_split_compartments(model: cobra.Model) -> int:
    """Reactions whose metabolites, apart from those they move between
    compartments, still sit in more than one compartment.

    A metabolite that appears in two compartments of the same reaction is what the
    reaction transports, and is ignored. The metabolites left over are the reaction's
    own chemistry, which normally takes place in one compartment; one of them in a
    different compartment (e.g. a cytosolic substrate in a mitochondrial reaction) is
    usually a curation error. Some enzymes do work across a membrane (e.g. HGSNAT,
    GPD2, fatty-acid uptake coupled to acyl-CoA synthesis), so this is a report, and
    only a rise in the count is flagged. Artificial (pool and biomass) reactions are
    skipped.
    """
    rows = []
    for rxn in model.reactions:
        # A subsystem is a string, or a list of them in the RAVEN 3 YAML format.
        subsystems = rxn.subsystem if isinstance(rxn.subsystem, list) else [rxn.subsystem]
        if "Artificial reactions" in subsystems:
            continue
        compartments_of = defaultdict(set)
        for met in rxn.metabolites:
            compartments_of[met.id[:-1]].add(met.compartment)
        chemistry = [m for m in rxn.metabolites if len(compartments_of[m.id[:-1]]) == 1]
        compartments = sorted({m.compartment for m in chemistry})
        if len(compartments) > 1:
            rows.append((rxn.id, rxn.name or "", "".join(compartments),
                         rxn.build_reaction_string(use_metabolite_names=True)))
    rows.sort()
    _write_csv(SPLIT_COMPARTMENT_CSV, ["reaction", "name", "compartments", "equation"], rows)
    return len(rows)


# --------------------------------------------------------------------------- #
# Report: metabolites / genes not used by any reaction
# --------------------------------------------------------------------------- #
def check_unused_entities(model: cobra.Model) -> tuple[int, int]:
    used_mets = {m.id for r in model.reactions for m in r.metabolites}
    used_genes = {g.id for r in model.reactions for g in r.genes}
    rows = [("metabolite", m.id) for m in model.metabolites if m.id not in used_mets]
    rows += [("gene", g.id) for g in model.genes if g.id not in used_genes]
    rows.sort()
    _write_csv(UNUSED_CSV, ["kind", "id"], rows)
    n_met = sum(1 for k, _ in rows if k == "metabolite")
    n_gene = sum(1 for k, _ in rows if k == "gene")
    return n_met, n_gene


# --------------------------------------------------------------------------- #
# Report: metabolites missing a formula or a charge
# --------------------------------------------------------------------------- #
def check_metabolite_completeness(model: cobra.Model) -> tuple[int, int]:
    rows = []
    for met in model.metabolites:
        if met.id[:-1] in PSEUDO_METABOLITES:
            continue
        missing_formula = not (met.formula or "").strip()
        missing_charge = met.charge is None
        if missing_formula or missing_charge:
            rows.append((met.id, met.name or "",
                         "yes" if missing_formula else "", "yes" if missing_charge else ""))
    rows.sort()
    _write_csv(COMPLETENESS_CSV, ["metabolite", "name", "missing_formula", "missing_charge"], rows)
    return sum(1 for r in rows if r[2]), sum(1 for r in rows if r[3])


# --------------------------------------------------------------------------- #
# Report: reaction bound / GPR sanity
# --------------------------------------------------------------------------- #
def check_reaction_sanity(model: cobra.Model) -> int:
    documented = set(_tsv_column(GENES_TSV, "genes"))
    rows = []
    for rxn in model.reactions:
        issues = []
        lb, ub = rxn.lower_bound, rxn.upper_bound
        if lb > ub:
            issues.append("lb>ub")
        if lb < -1000 or ub > 1000:
            issues.append("|bound|>1000")
        undocumented = sorted(g.id for g in rxn.genes if g.id not in documented)
        if undocumented:
            issues.append("undocumented_genes:" + ";".join(undocumented))
        if rxn.boundary and rxn.gene_reaction_rule.strip():
            issues.append("boundary_with_gpr")
        if issues:
            rows.append((rxn.id, rxn.name or "", ";".join(issues)))
    rows.sort()
    _write_csv(REACTION_SANITY_CSV, ["reaction", "name", "issues"], rows)
    return len(rows)


def check_name_consistency(model: cobra.Model) -> list[tuple]:
    """Names that are missing, or that disagree between a metabolite's compartments.

    Names are curated in model/Human-GEM.yml, and reactions.tsv/metabolites.tsv carry
    cross-references only, so there is no second copy of a name to drift against. Two
    things can still go wrong:

    * an entity with no name, which the naming curation brought to zero;
    * one chemical carrying different names in different compartments. The same
      compound is the same compound wherever it sits, so the names should agree, and a
      disagreement is either a naming slip or two unrelated compounds sharing a base
      identifier.

    Returns [(kind, id, issue)].
    """
    rows: list[tuple] = []
    for kind, entities in (("reaction", model.reactions), ("metabolite", model.metabolites)):
        for entity in entities:
            if not (entity.name or "").strip():
                rows.append((kind, entity.id, "missing name"))

    # Metabolite ids are the base identifier plus a one-letter compartment suffix.
    names_by_base: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
    for met in model.metabolites:
        base = met.id[:-1] if met.id[-1:].isalpha() else met.id
        names_by_base[base][(met.name or "").strip()].append(met.id)
    for base, by_name in sorted(names_by_base.items()):
        if len(by_name) > 1:
            spelled = "; ".join(
                f"{name!r} ({', '.join(sorted(ids))})" for name, ids in sorted(by_name.items())
            )
            rows.append(("metabolite", base, f"name differs across compartments: {spelled}"))

    rows.sort()
    _write_csv(NAME_CONSISTENCY_CSV, ["kind", "id", "issue"], rows)
    return rows


# --------------------------------------------------------------------------- #
# Gate: growth, with the blocking biomass precursors when it fails
# --------------------------------------------------------------------------- #
def _medium_inputs(path: str = MEDIUM_TASKS_FILE, task_id: str = MEDIUM_TASK_ID) -> list[str]:
    """The IN metabolites (``name[compartment]``) of one task in a RAVEN task list."""
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh, delimiter="\t"))
    header = rows[0]
    id_col, in_col = header.index("ID"), header.index("IN")
    inputs, in_task = [], False
    for row in rows[1:]:
        row = row + [""] * (len(header) - len(row))
        if row[id_col].strip():
            if in_task:
                break
            in_task = row[id_col].strip() == task_id
        if in_task and row[in_col].strip():
            inputs.append(row[in_col].strip())
    return inputs


def apply_growth_medium(model: cobra.Model) -> list[str]:
    """Close every uptake, then open the medium's inputs (capped, see above).
    Call inside ``with model:``. Returns the inputs no exchange reaction matched."""
    for rxn in model.boundary:
        rxn.lower_bound = 0
    unresolved = []
    for token in _medium_inputs():
        name, compartment = token.rsplit("[", 1)
        compartment = compartment.rstrip("]")
        exchanges = [rxn for met in model.metabolites
                     if met.name == name and met.compartment == compartment
                     for rxn in met.reactions if rxn.boundary]
        if not exchanges:
            unresolved.append(token)
        cap = 1000.0 if name in MEDIUM_UNCAPPED else MEDIUM_UPTAKE_CAP
        for rxn in exchanges:
            rxn.lower_bound = -cap
    return unresolved


def check_growth(model: cobra.Model) -> float:
    with model:
        unresolved = apply_growth_medium(model)
        if unresolved:
            print(f"::warning::Medium inputs without an exchange reaction: {', '.join(unresolved)}")
        value = model.slim_optimize()
    return float(value) if value is not None else float("nan")


def write_growth_blockers(model: cobra.Model) -> list[str]:
    """When the model cannot grow, list the biomass precursors it cannot make.

    For each reactant of the objective (biomass) reaction, add a temporary demand
    and see whether any positive flux can be driven through it. Precursors that
    cannot be produced are what to fix. Runs only on a growth failure.
    """
    blockers: list[str] = []
    try:
        objective = [r for r in model.reactions if r.objective_coefficient != 0]
        precursors = sorted({m.id for r in objective for m, c in r.metabolites.items() if c < 0})
        for met_id in precursors:
            with model:
                apply_growth_medium(model)
                met = model.metabolites.get_by_id(met_id)
                demand = model.add_boundary(met, type="demand")
                model.objective = demand
                flux = model.slim_optimize()
            if flux is None or abs(flux) <= GROWTH_TOLERANCE:
                blockers.append(met_id)
    except Exception as exc:  # noqa: BLE001 - diagnostics must never mask the growth failure
        print(f"::warning::Could not compute biomass-precursor blockers ({exc}).")
    _write_csv(GROWTH_BLOCKERS_CSV, ["blocked_biomass_precursor"], [(b,) for b in blockers])
    return blockers


def main() -> int:
    gate_failed = False

    # 1. Duplicate keys must run before the cobra load: if they exist, the load
    #    below is the bare AssertionError we are trying to explain.
    duplicates = check_no_duplicate_keys(MODEL_FILE)
    if duplicates:
        for entry_id, scope, key, first_line, dup_line in duplicates:
            print(f"::error::Duplicate {scope} '{key}' in entry {entry_id} "
                  f"({MODEL_FILE} lines {first_line} and {dup_line}).")
        print(f"Found {len(duplicates)} duplicate key(s); see {DUP_KEYS_CSV}. "
              f"cobra cannot load a model with duplicate keys in an !!omap block.")
        # Cannot load the model, so cannot run the rest; fail now.
        return 1

    model = cobra.io.load_yaml_model(MODEL_FILE)
    # GLPK for the growth LP so this does not depend on a Gurobi licence.
    model.solver = "glpk"

    # Non-blocking checks: written to CSV and tracked with a delta in the comment
    # (a rising count shows as a regression), but they do not fail the build. The
    # only gate that blocks the merge here is growth (and duplicate keys above,
    # which stops the model loading at all).
    empty = check_empty_reactions(model)
    if empty:
        print(f"::warning::{len(empty)} reaction(s) have no metabolites; see {EMPTY_RXN_CSV}.")

    annotation = check_annotation_consistency(model)
    if annotation:
        print(f"::warning::{len(annotation)} model/annotation-table inconsistency(ies); "
              f"see {ANNOTATION_CONSISTENCY_CSV}.")

    undeprecated = check_deprecation_completeness(model)
    if undeprecated:
        print(f"::warning::{len(undeprecated)} identifier(s) removed from the model but not "
              f"added to a deprecated list; see {DEPRECATION_COMPLETENESS_CSV}.")

    growth = check_growth(model)
    grows = growth == growth and growth > GROWTH_TOLERANCE  # not NaN and positive
    qcStatus.set_status("growth", f"{growth:.6g}")
    if not grows:
        blockers = write_growth_blockers(model)
        print(f"::error::Model cannot produce biomass on the defined medium "
              f"({len(blockers)} blocked precursor(s); see {GROWTH_BLOCKERS_CSV}).")
        gate_failed = True
    else:
        _write_csv(GROWTH_BLOCKERS_CSV, ["blocked_biomass_precursor"], [])

    # Reports (never fail the build)
    n_formula, n_charge = check_metabolite_completeness(model)
    n_reaction_issues = check_reaction_sanity(model)
    n_dup_rxn = check_duplicate_reactions(model)
    n_split = check_split_compartments(model)
    n_unused_met, n_unused_gene = check_unused_entities(model)

    name_issues = check_name_consistency(model)
    if name_issues:
        print(f"::warning::{len(name_issues)} naming issue(s); see {NAME_CONSISTENCY_CSV}.")

    print(f"Metabolites missing a formula: {n_formula}")
    print(f"Metabolites missing a charge: {n_charge}")
    print(f"Reactions with bound/GPR issues: {n_reaction_issues}")
    print(f"Naming issues (missing or inconsistent): {len(name_issues)}")
    print(f"Exact-duplicate reaction groups: {n_dup_rxn}")
    print(f"Reactions with chemistry split across compartments: {n_split}")
    print(f"Unused metabolites / genes: {n_unused_met} / {n_unused_gene}")
    print(f"Removed identifiers not deprecated: {len(undeprecated)}")
    print(f"Growth (max biomass, defined medium): {growth:.4g} "
          f"({'ok' if grows else 'NO GROWTH'})")

    return 1 if gate_failed else 0


if __name__ == "__main__":
    sys.exit(main())

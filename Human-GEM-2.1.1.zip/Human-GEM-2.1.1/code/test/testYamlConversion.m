function status = testYamlConversion
% test the functions for yaml import/export see if the conversion process
% changes the model content
%

% Get model path
[ST, I]=dbstack('-completenames');
modelPath=fileparts(fileparts(fileparts(ST(I).file)));

% export to yml and then import back
try

    % Import yaml model
    ymlFile=fullfile(modelPath,'model','Human-GEM.yml');
    model = readYAMLmodel(ymlFile, true);

    % make sure there is no intermediate Yaml file under the current folder
    warning('off', 'MATLAB:DELETE:FileNotFound')
    if exist('testYamlConversion.yml','file')
        delete testYamlConversion.yml;
    end

    writeYAMLmodel(model,'testYamlConversion.yml');
    importedHumanGEM = readYAMLmodel('testYamlConversion.yml', true);

    if isfield(model,'date')
        model = rmfield(model,'date');
    end
    if isfield(importedHumanGEM,'date')
        importedHumanGEM = rmfield(importedHumanGEM,'date');
    end

    % remove intermediate Yaml file
    delete testYamlConversion.yml;

    % compare the imported model from yaml with the original one
    if ~isequal(model, importedHumanGEM)
        warning('::error::Re-imported model is diffrent from export');
        exit(1);
    end
catch
    warning('::error::There are problems during the conversion import and export');
    exit(1)
end

% model conversion between Matlab and Yaml files is successful
disp('The conversion was successful.')
exit(0)